# phpMyEdit-PHP7.0
phpMyEdit working on PHP7.0 http://opensource.platon.org/projects/bug_view_advanced_page.php?f_bug_id=782
